import { z } from "zod";
import type {
  DiagnosaAiModelResponse,
  DiagnosaAiSnapshot,
} from "@/lib/diagnosa-ai/diagnosa-ai.types";

export const MAX_DIAGNOSA_AI_IMAGE_BYTES = 5 * 1024 * 1024;

const ACCEPTED_IMAGE_MIME_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
];

export const diagnosaAiChatRequestSchema = z.object({
  message: z.string().trim().min(1, "Pesan wajib diisi."),
  imageBase64: z.string().trim().nullable().optional(),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().trim().min(1),
      })
    )
    .optional()
    .default([]),
  diagnosaAiId: z.string().trim().nullable().optional(),
});

const diagnosaAiSnapshotSchema = z.object({
  gejala: z.string().min(1),
  kemungkinanPenyebab: z.array(z.string().min(1)).min(2),
  kemungkinanSolusi: z.array(z.string().min(1)).min(2),
  saranTindakan: z.array(z.string().min(1)).min(2),
  tingkatUrgensi: z.enum(["rendah", "sedang", "tinggi"]),
  perluServisLangsung: z.boolean(),
  disclaimer: z.string().min(1),
});

export const diagnosaAiModelResponseSchema = z
  .object({
    assistantReply: z.string().min(1),
    isDiagnosis: z.boolean().optional(),
    snapshot: diagnosaAiSnapshotSchema.nullable(),
  })
  .superRefine((value, ctx) => {
    const isDiagnosis = value.isDiagnosis ?? value.snapshot !== null;

    if (isDiagnosis && !value.snapshot) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["snapshot"],
        message: "Snapshot wajib ada jika isDiagnosis bernilai true.",
      });
    }
  })
  .transform((value): DiagnosaAiModelResponse => {
    const isDiagnosis = value.isDiagnosis ?? value.snapshot !== null;

    return {
      assistantReply: value.assistantReply,
      isDiagnosis,
      snapshot: isDiagnosis ? value.snapshot : null,
    };
  });

export function parseModelJson(text: string): DiagnosaAiModelResponse {
  const cleaned = text
    .trim()
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "");

  const parsed = JSON.parse(cleaned);
  return diagnosaAiModelResponseSchema.parse(parsed);
}

export function normalizeDiagnosaAiId(value?: string | null) {
  if (!value) return null;

  try {
    return BigInt(value);
  } catch {
    return null;
  }
}

export function serializeBigInt<T>(data: T): T {
  return JSON.parse(
    JSON.stringify(data, (_, value) =>
      typeof value === "bigint" ? value.toString() : value
    )
  );
}

export function buildSavedSnapshotStrings(snapshot: DiagnosaAiSnapshot) {
  return {
    gejala: snapshot.gejala,
    kemungkinan_penyebab: snapshot.kemungkinanPenyebab.join("\n- "),
    kemungkinan_solusi: snapshot.kemungkinanSolusi.join("\n- "),
    saran_tindakan: snapshot.saranTindakan.join("\n- "),
  };
}

export function normalizeImageMarker(imageBase64?: string | null) {
  if (!imageBase64) return null;
  return "[image-attached]";
}

export function getBase64SizeInBytes(base64: string) {
  const normalized = base64.replace(/\s/g, "");
  const padding = normalized.endsWith("==")
    ? 2
    : normalized.endsWith("=")
      ? 1
      : 0;

  return Math.floor((normalized.length * 3) / 4) - padding;
}

export function extractBase64ImageData(value?: string | null) {
  if (!value) return null;

  const trimmed = value.trim();

  if (!trimmed || trimmed.startsWith("blob:")) {
    return null;
  }

  if (trimmed.startsWith("data:image/")) {
    const match = trimmed.match(
      /^data:(image\/[a-zA-Z0-9.+-]+);base64,([\s\S]+)$/
    );

    if (!match) return null;

    const mimeType = match[1]?.toLowerCase();
    const pureBase64 = match[2]?.replace(/\s/g, "") ?? "";

    if (!mimeType || !ACCEPTED_IMAGE_MIME_TYPES.includes(mimeType)) {
      return null;
    }

    if (!pureBase64 || !/^[A-Za-z0-9+/]+=*$/.test(pureBase64)) {
      return null;
    }

    return {
      data: pureBase64,
      mimeType: mimeType === "image/jpg" ? "image/jpeg" : mimeType,
      sizeBytes: getBase64SizeInBytes(pureBase64),
    };
  }

  const maybePureBase64 = trimmed.replace(/\s/g, "");

  if (/^[A-Za-z0-9+/]+=*$/.test(maybePureBase64)) {
    return {
      data: maybePureBase64,
      mimeType: "image/jpeg",
      sizeBytes: getBase64SizeInBytes(maybePureBase64),
    };
  }

  return null;
}

export function buildNextHistory(params: {
  history: { role: "user" | "assistant"; content: string }[];
  userMessage: string;
  assistantMessage: string;
}) {
  return [
    ...params.history,
    {
      role: "user" as const,
      content: params.userMessage,
    },
    {
      role: "assistant" as const,
      content: params.assistantMessage,
    },
  ];
}